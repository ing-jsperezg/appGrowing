<nav class="full-box navbar-info">
	<a href="#" class="float-left show-nav-lateral">
		<i class="fas fa-exchange-alt"></i>
	</a>
	<a href="<?php echo SERVERURL; ?>user-update/">
		<i class="fas fa-user-cog"></i>
	</a>
	<a href="#" class="btn-exit-system">
		<i class="fas fa-power-off"></i>
	</a>
</nav>